import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _61637405 = () => interopDefault(import('..\\pages\\about_us\\about_us.vue' /* webpackChunkName: "pages_about_us_about_us" */))
const _4bee4225 = () => interopDefault(import('..\\pages\\cart\\cart.vue' /* webpackChunkName: "pages_cart_cart" */))
const _02ac7085 = () => interopDefault(import('..\\pages\\competition\\competition.vue' /* webpackChunkName: "pages_competition_competition" */))
const _96d3915c = () => interopDefault(import('..\\pages\\goods\\detail.vue' /* webpackChunkName: "pages_goods_detail" */))
const _da506a14 = () => interopDefault(import('..\\pages\\goods\\goodsdetail.vue' /* webpackChunkName: "pages_goods_goodsdetail" */))
const _18263403 = () => interopDefault(import('..\\pages\\goods\\goodslist.vue' /* webpackChunkName: "pages_goods_goodslist" */))
const _6a40b83a = () => interopDefault(import('..\\pages\\group\\grouplist.vue' /* webpackChunkName: "pages_group_grouplist" */))
const _cd2dd622 = () => interopDefault(import('..\\pages\\information\\article.vue' /* webpackChunkName: "pages_information_article" */))
const _592299a5 = () => interopDefault(import('..\\pages\\information\\information.vue' /* webpackChunkName: "pages_information_information" */))
const _9d2f02cc = () => interopDefault(import('..\\pages\\layout\\eventBus.js' /* webpackChunkName: "pages_layout_eventBus" */))
const _6b92b1aa = () => interopDefault(import('..\\pages\\layout\\footer.vue' /* webpackChunkName: "pages_layout_footer" */))
const _e675d4c8 = () => interopDefault(import('..\\pages\\layout\\header.vue' /* webpackChunkName: "pages_layout_header" */))
const _61bf7ca2 = () => interopDefault(import('..\\pages\\layout\\news.vue' /* webpackChunkName: "pages_layout_news" */))
const _b4da14f6 = () => interopDefault(import('..\\pages\\login\\login.vue' /* webpackChunkName: "pages_login_login" */))
const _0819ff8a = () => interopDefault(import('..\\pages\\login\\regist.vue' /* webpackChunkName: "pages_login_regist" */))
const _661f09e5 = () => interopDefault(import('..\\pages\\order\\order.vue' /* webpackChunkName: "pages_order_order" */))
const _01f915b6 = () => interopDefault(import('..\\pages\\pay\\pay.vue' /* webpackChunkName: "pages_pay_pay" */))
const _f2af027a = () => interopDefault(import('..\\pages\\pay\\payfail.vue' /* webpackChunkName: "pages_pay_payfail" */))
const _db7737f6 = () => interopDefault(import('..\\pages\\seckill\\seckill.vue' /* webpackChunkName: "pages_seckill_seckill" */))
const _35dce106 = () => interopDefault(import('..\\pages\\user\\content_left.vue' /* webpackChunkName: "pages_user_content_left" */))
const _54a83c3b = () => interopDefault(import('..\\pages\\user\\user.vue' /* webpackChunkName: "pages_user_user" */))
const _0a642ede = () => interopDefault(import('..\\pages\\user\\account\\account_safety.vue' /* webpackChunkName: "pages_user_account_account_safety" */))
const _1445fd50 = () => interopDefault(import('..\\pages\\user\\account\\address.js' /* webpackChunkName: "pages_user_account_address" */))
const _580bc17d = () => interopDefault(import('..\\pages\\user\\account\\address_manage.vue' /* webpackChunkName: "pages_user_account_address_manage" */))
const _033cfd5b = () => interopDefault(import('..\\pages\\user\\account\\address_management.vue' /* webpackChunkName: "pages_user_account_address_management" */))
const _a02e76ca = () => interopDefault(import('..\\pages\\user\\account\\address-data.min.js' /* webpackChunkName: "pages_user_account_address-data.min" */))
const _28873e24 = () => interopDefault(import('..\\pages\\user\\account\\addressdata.js' /* webpackChunkName: "pages_user_account_addressdata" */))
const _4378b8a6 = () => interopDefault(import('..\\pages\\user\\account\\change_password.vue' /* webpackChunkName: "pages_user_account_change_password" */))
const _6e928661 = () => interopDefault(import('..\\pages\\user\\account\\my_message.vue' /* webpackChunkName: "pages_user_account_my_message" */))
const _62b33178 = () => interopDefault(import('..\\pages\\user\\account\\packet_records.vue' /* webpackChunkName: "pages_user_account_packet_records" */))
const _7fa20115 = () => interopDefault(import('..\\pages\\user\\account\\r.vue' /* webpackChunkName: "pages_user_account_r" */))
const _0973ce69 = () => interopDefault(import('..\\pages\\user\\activity\\join_competition.vue' /* webpackChunkName: "pages_user_activity_join_competition" */))
const _d62c559a = () => interopDefault(import('..\\pages\\user\\activity\\start_competition.vue' /* webpackChunkName: "pages_user_activity_start_competition" */))
const _ea38100a = () => interopDefault(import('..\\pages\\user\\invite\\cash_out.vue' /* webpackChunkName: "pages_user_invite_cash_out" */))
const _1b9242d8 = () => interopDefault(import('..\\pages\\user\\invite\\invite_friends.vue' /* webpackChunkName: "pages_user_invite_invite_friends" */))
const _beee6cf0 = () => interopDefault(import('..\\pages\\user\\invite\\return_ceremony.vue' /* webpackChunkName: "pages_user_invite_return_ceremony" */))
const _413110f0 = () => interopDefault(import('..\\pages\\user\\order\\order_detail.vue' /* webpackChunkName: "pages_user_order_order_detail" */))
const _1ec68910 = () => interopDefault(import('..\\pages\\user\\order\\order_evaluate.vue' /* webpackChunkName: "pages_user_order_order_evaluate" */))
const _eac9e3a0 = () => interopDefault(import('..\\pages\\user\\order\\order_group.vue' /* webpackChunkName: "pages_user_order_order_group" */))
const _30c2230b = () => interopDefault(import('..\\pages\\user\\order\\order_integral.vue' /* webpackChunkName: "pages_user_order_order_integral" */))
const _5abf1344 = () => interopDefault(import('..\\pages\\user\\order\\order_logistics.vue' /* webpackChunkName: "pages_user_order_order_logistics" */))
const _503e36c0 = () => interopDefault(import('..\\pages\\user\\order\\order_seckill.vue' /* webpackChunkName: "pages_user_order_order_seckill" */))
const _762447dc = () => interopDefault(import('..\\pages\\user\\vipServices\\my_comments.vue' /* webpackChunkName: "pages_user_vipServices_my_comments" */))
const _54dc1f06 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about_us/about_us",
    component: _61637405,
    name: "about_us-about_us"
  }, {
    path: "/cart/cart",
    component: _4bee4225,
    name: "cart-cart"
  }, {
    path: "/competition/competition",
    component: _02ac7085,
    name: "competition-competition"
  }, {
    path: "/goods/detail",
    component: _96d3915c,
    name: "goods-detail"
  }, {
    path: "/goods/goodsdetail",
    component: _da506a14,
    name: "goods-goodsdetail"
  }, {
    path: "/goods/goodslist",
    component: _18263403,
    name: "goods-goodslist"
  }, {
    path: "/group/grouplist",
    component: _6a40b83a,
    name: "group-grouplist"
  }, {
    path: "/information/article",
    component: _cd2dd622,
    name: "information-article"
  }, {
    path: "/information/information",
    component: _592299a5,
    name: "information-information"
  }, {
    path: "/layout/eventBus",
    component: _9d2f02cc,
    name: "layout-eventBus"
  }, {
    path: "/layout/footer",
    component: _6b92b1aa,
    name: "layout-footer"
  }, {
    path: "/layout/header",
    component: _e675d4c8,
    name: "layout-header"
  }, {
    path: "/layout/news",
    component: _61bf7ca2,
    name: "layout-news"
  }, {
    path: "/login/login",
    component: _b4da14f6,
    name: "login-login"
  }, {
    path: "/login/regist",
    component: _0819ff8a,
    name: "login-regist"
  }, {
    path: "/order/order",
    component: _661f09e5,
    name: "order-order"
  }, {
    path: "/pay/pay",
    component: _01f915b6,
    name: "pay-pay"
  }, {
    path: "/pay/payfail",
    component: _f2af027a,
    name: "pay-payfail"
  }, {
    path: "/seckill/seckill",
    component: _db7737f6,
    name: "seckill-seckill"
  }, {
    path: "/user/content_left",
    component: _35dce106,
    name: "user-content_left"
  }, {
    path: "/user/user",
    component: _54a83c3b,
    name: "user-user"
  }, {
    path: "/user/account/account_safety",
    component: _0a642ede,
    name: "user-account-account_safety"
  }, {
    path: "/user/account/address",
    component: _1445fd50,
    name: "user-account-address"
  }, {
    path: "/user/account/address_manage",
    component: _580bc17d,
    name: "user-account-address_manage"
  }, {
    path: "/user/account/address_management",
    component: _033cfd5b,
    name: "user-account-address_management"
  }, {
    path: "/user/account/address-data.min",
    component: _a02e76ca,
    name: "user-account-address-data.min"
  }, {
    path: "/user/account/addressdata",
    component: _28873e24,
    name: "user-account-addressdata"
  }, {
    path: "/user/account/change_password",
    component: _4378b8a6,
    name: "user-account-change_password"
  }, {
    path: "/user/account/my_message",
    component: _6e928661,
    name: "user-account-my_message"
  }, {
    path: "/user/account/packet_records",
    component: _62b33178,
    name: "user-account-packet_records"
  }, {
    path: "/user/account/r",
    component: _7fa20115,
    name: "user-account-r"
  }, {
    path: "/user/activity/join_competition",
    component: _0973ce69,
    name: "user-activity-join_competition"
  }, {
    path: "/user/activity/start_competition",
    component: _d62c559a,
    name: "user-activity-start_competition"
  }, {
    path: "/user/invite/cash_out",
    component: _ea38100a,
    name: "user-invite-cash_out"
  }, {
    path: "/user/invite/invite_friends",
    component: _1b9242d8,
    name: "user-invite-invite_friends"
  }, {
    path: "/user/invite/return_ceremony",
    component: _beee6cf0,
    name: "user-invite-return_ceremony"
  }, {
    path: "/user/order/order_detail",
    component: _413110f0,
    name: "user-order-order_detail"
  }, {
    path: "/user/order/order_evaluate",
    component: _1ec68910,
    name: "user-order-order_evaluate"
  }, {
    path: "/user/order/order_group",
    component: _eac9e3a0,
    name: "user-order-order_group"
  }, {
    path: "/user/order/order_integral",
    component: _30c2230b,
    name: "user-order-order_integral"
  }, {
    path: "/user/order/order_logistics",
    component: _5abf1344,
    name: "user-order-order_logistics"
  }, {
    path: "/user/order/order_seckill",
    component: _503e36c0,
    name: "user-order-order_seckill"
  }, {
    path: "/user/vipServices/my_comments",
    component: _762447dc,
    name: "user-vipServices-my_comments"
  }, {
    path: "/",
    component: _54dc1f06,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
